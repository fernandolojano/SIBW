
$(document).ready(
    function cargarDatos(){
        $('#search').keyup(
            function (){
                var consulta = $(this).val();
                // Cada vez que venga un dato consulta en la BD con AJAX
                if( consulta != ''){
                    $.ajax({
                    url: "search.php",
                    method: "POST",
                    data: {consulta: consulta},
                    success: function mostrarEventos(datos){
                        $("#resultados").fadeIn();
                        $("#resultados").html(datos);
                    }
                    });
                }
                else{
                    $("#resultados").fadeOut();
                }
                // Al hacer clic se autocompleta el cuadro
                $(document).on('click', 'li', function(){
                    $('#search').val($(this).text());
                    $("#resultados").fadeOut();
                })
            }
        );
    }
);


